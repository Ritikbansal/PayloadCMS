import ContactUsPage from '../contact-us/page'

export default ContactUsPage
